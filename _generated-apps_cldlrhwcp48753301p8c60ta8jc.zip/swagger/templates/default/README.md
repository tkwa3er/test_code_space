# swagger-typescript-api  

# templates/default  

This templates use for single api file (without `--modular` option)  

path prefix `@default`  
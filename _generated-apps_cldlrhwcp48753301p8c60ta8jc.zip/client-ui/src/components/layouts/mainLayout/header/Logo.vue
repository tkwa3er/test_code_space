<template>
  <!--begin::Actions-->
  <div class="d-flex align-items-center py-1">
    <!--begin::Mobile logo-->

    <img
      alt="Logo"
      src="/svg/logos/logo.svg"
      class="h-30px"
    />

    <!--end::Mobile logo-->
  </div>
  <!--end::Actions-->
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "logo",
  components: {},
});
</script>
